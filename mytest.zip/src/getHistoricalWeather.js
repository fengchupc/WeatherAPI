import axios from 'axios';
import AWS from 'aws-sdk';

const s3 = new AWS.S3();

const API_KEY = process.env.API_KEY;
const BUCKET_NAME = process.env.BUCKET_NAME;

const getHistoricalWeather = async (city) => {
	// const city = event.pathParameters.city;
	const end = new Date();
	const start = new Date(end.getTime() - 30 * 24 * 60 * 60 * 1000); // 30 days before

	try {
		// Get historical data from S3
		const s3Params = {
		  Bucket: BUCKET_NAME,
		  Prefix: `weather/${city}/`
		};

		const files = await s3.listObjectsV2(s3Params).promise();

		// Fallback: if no historical data, fetch from OpenWeather API
		if (!files.Contents.length) {
			start = Math.floor(start.getTime() / 1000);
			end = Math.floor(end.getTime() / 1000);
			const historyData = await axios.get(`https://history.openweathermap.org/data/2.5/history/city?q=${city}&type=hour&start=${start}&end=${end}&appid=${API_KEY}`);
			const data = historyData.data;

		if (data) {
			// Store the response in S3
			const s3PutParams = {
				Bucket: BUCKET_NAME,
				Key: `weather/${city}/last30days.json`,
				Body: JSON.stringify(data),
				ContentType: 'application/json'
			};
			await s3.putObject(s3PutParams).promise();
			return {
				statusCode: 200,
				body: JSON.stringify(data)
			};
		}

			return {
				statusCode: 404,
				body: JSON.stringify({ message: 'No historical data available for this city.' })
			};	
		}

		// Fetch historical data from S3
		const history = await Promise.all(files.Contents.map(async (file) => {
			const data = await s3.getObject({ Bucket: BUCKET_NAME, Key: file.Key }).promise();
			return JSON.parse(data.Body.toString());
		}));

		return {
			statusCode: 200,
			body: JSON.stringify(history)
		};
	} catch (error) {
		console.error('Error fetching historical weather data:', error);
		return {
			statusCode: 500,
			body: JSON.stringify({ error: 'Could not fetch historical weather data.' })
		};
	}
};

export default getHistoricalWeather;
