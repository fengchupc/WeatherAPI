import axios from 'axios';
import AWS from 'aws-sdk';

const s3 = new AWS.S3();

const API_KEY = process.env.API_KEY;
const BUCKET_NAME = process.env.BUCKET_NAME;

const getCurrentWeather = async (city) => {
  // const city = event.pathParameters.city;
  console.log("Fetching weather data for city:", city);
  try {
    // Fetch current weather data from OpenWeatherMap API
    const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}`);
    const data = response.data;

    // Store the response in S3 
    const s3Params = {
      Bucket: BUCKET_NAME,
      Key: `weather/${city}/current.json`,
      Body: JSON.stringify(data),
      ContentType: 'application/json'
    };
    console.log("Storing data to S3 with params:", s3Params);
    await s3.putObject(s3Params).promise();


    console.log("Fetched weather data:", data);
    console.log("Storing data to S3 with params:", s3Params);
    console.error("Error fetching or storing data:", e);


    return {
      statusCode: 200,
      body: JSON.stringify(data)
    };
  } catch (e) {
    return {
      statusCode: 500,
      body: JSON.stringify({ e: 'Could not fetch current weather data.' })
    };
  }
};

export default getCurrentWeather;
