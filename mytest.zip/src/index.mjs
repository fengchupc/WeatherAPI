import getCurrentWeather from './getCurrentWeather.js';
import getHistoricalWeather from './getHistoricalWeather.js';

export const handler = async (event) => {
  const path = event.resource; // e.g., /weather/{city} or /weather/history/{city}
  const city = event.pathParameters.city;

  try {
    if (path === '/weather/{city}') {
      return await getCurrentWeather(city);
    } else if (path === '/weather/history/{city}') {
      return await getHistoricalWeather(city);
    } else {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: 'Route not found.' }),
      };
    }
  } catch (error) {
    console.error("Error routing request:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error' }),
    };
  }
};
